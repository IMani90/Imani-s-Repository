import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Main {

    private static String API_KEY;
    private static final String BASE_URL = "https://api.openweathermap.org/data/2.5/weather";
    private static final String LOCATION = "Menomonee Falls,WI,US";

    public static void main(String[] args) throws IOException, InterruptedException {
        loadApiKey();

        // GET request: fetch weather
        getWeather();

        // POST, PUT, DELETE are simulated using a test API
        postExample();
        putExample();
        deleteExample();
    }

    // Load API key from .env
    private static void loadApiKey() throws IOException {
        Properties props = new Properties();
        try (var reader = Files.newBufferedReader(Paths.get(".env"))) {
            props.load(reader);
            API_KEY = props.getProperty("OPENWEATHER_API_KEY");
        }
    }

    // GET method
    private static void getWeather() throws IOException, InterruptedException {
        String encodedLocation = URLEncoder.encode(LOCATION, StandardCharsets.UTF_8);
        String url = BASE_URL + "?q=" + encodedLocation + "&appid=" + API_KEY + "&units=metric";
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("GET Response:");
        System.out.println(response.body());
    }

    // POST example (simulated)
    private static void postExample() throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://jsonplaceholder.typicode.com/posts"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString("{\"title\":\"foo\",\"body\":\"bar\",\"userId\":1}"))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("POST Response:");
        System.out.println(response.body());
    }

    // PUT example (simulated)
    private static void putExample() throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://jsonplaceholder.typicode.com/posts/1"))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString("{\"id\":1,\"title\":\"updated\",\"body\":\"bar updated\",\"userId\":1}"))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("PUT Response:");
        System.out.println(response.body());
    }

    // DELETE example (simulated)
    private static void deleteExample() throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://jsonplaceholder.typicode.com/posts/1"))
                .DELETE()
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("DELETE Response:");
        System.out.println(response.body());
    }
}
