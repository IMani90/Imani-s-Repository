# Weather API Java Project

## Overview
This project demonstrates the use of a Weather API to fetch and manipulate weather data using Java. The program uses the GET, POST, PUT, and DELETE methods to interact with the API and manage data.

---

## Questions

### 1) How easy was the implementation of the API into your program?
Implementing the API was moderately straightforward. The API documentation was clear, and using Java libraries for HTTP requests simplified the process. The main challenge was properly handling API keys securely through a `.env` file and ensuring that the program could parse JSON responses correctly.

### 2) What did you learn from trying to use the 4 methods to manipulate the program?
Using the 4 methods helped me understand the different ways a program can interact with a web API:

- **GET**: Fetching data from the API and displaying current weather conditions.
- **POST**: Sending new data to the API (simulated or real depending on the API).
- **PUT**: Updating existing data in the API and seeing how changes are applied.
- **DELETE**: Removing data and observing how the API responds to deletion requests.

This process reinforced the concepts of RESTful APIs and the importance of handling responses and errors properly.

### 3) Why did you choose this API?
I chose the Weather API because of the recent flooding issues that happened around my location, and I was keen to use the API key to understand real-world data. It allowed me to demonstrate API integration clearly, while also giving me the opportunity to work with JSON data, API keys, and multiple HTTP methods in a meaningful context. I know there were limitations in POST, PUT, and DELETE.

---

## Run Steps and Output
1. Clone this repository.
2. Create a `.env` file in the project root and add your API key:

Run the program using my terminal:

javac Main.java
java Main

Output I got:
GET Response:
{"coord":{"lon":-88.1173,"lat":43.1789},"weather":[{"id":803,"main":"Clouds","description":"broken clouds","icon":"04d"}],"base":"stations","main":{"temp":26.49,"feels_like":26.49,"temp_min":24.82,"temp_max":27.99,"pressure":1014,"humidity":57,"sea_level":1014,"grnd_level":982},"visibility":10000,"wind":{"speed":4.63,"deg":320,"gust":10.29},"clouds":{"all":75},"dt":1755114125,"sys":{"type":2,"id":2035550,"country":"US","sunrise":1755082571,"sunset":1755133115},"timezone":-18000,"id":5262630,"name":"Menomonee Falls","cod":200}
POST Response:
{
  "title": "foo",
  "body": "bar",
  "userId": 1,
  "id": 101
}
PUT Response:
{
  "id": 1,
  "title": "updated",
  "body": "bar updated",
  "userId": 1
}
DELETE Response:
{}
